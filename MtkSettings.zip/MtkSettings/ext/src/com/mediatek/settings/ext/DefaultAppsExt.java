package com.mediatek.settings.ext;

import android.content.Context;
import android.support.v7.preference.PreferenceScreen;

public class DefaultAppsExt implements IAppsExt {

    public DefaultAppsExt(Context context) {

    }
    /**
     * @param prefScreen
     *            customized prefScreen
     * @internal
     */
    public void launchApp(PreferenceScreen prefScreen, String packageName){
    }
}
