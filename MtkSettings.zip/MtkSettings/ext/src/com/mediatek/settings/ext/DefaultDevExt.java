package com.mediatek.settings.ext;


import android.content.Context;
import androidx.preference.Preference;


public class DefaultDevExt implements IDevExt {

    public DefaultDevExt(Context context) {

    }

     /**
      * @param pref customized preference
      *
      */
    public void customUSBPreference(Preference pref){

    }
}
