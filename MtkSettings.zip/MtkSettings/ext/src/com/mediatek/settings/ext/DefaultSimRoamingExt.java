package com.mediatek.settings.ext;


public class DefaultSimRoamingExt implements ISimRoamingExt {

    /**
     * show Toast for succeeding to enable or disable pin lock
     */
    public void showPinToast(boolean enable) {
    }
}
