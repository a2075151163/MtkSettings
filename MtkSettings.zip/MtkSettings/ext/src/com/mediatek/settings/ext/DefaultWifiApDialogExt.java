package com.mediatek.settings.ext;

import android.content.Context;
import android.widget.Spinner;

public class DefaultWifiApDialogExt implements IWifiApDialogExt {
    private static final String TAG = "DefaultWifiApDialogExt";

    public void setAdapter(Context context, Spinner spinner, int arrayId) {
    }
}
