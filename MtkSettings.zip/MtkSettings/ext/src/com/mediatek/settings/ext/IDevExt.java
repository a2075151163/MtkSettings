package com.mediatek.settings.ext;

import androidx.preference.Preference;


public interface IDevExt {

     /**
      * @param pref customized preference
      * @internal
      */
     void customUSBPreference(Preference pref);

}
