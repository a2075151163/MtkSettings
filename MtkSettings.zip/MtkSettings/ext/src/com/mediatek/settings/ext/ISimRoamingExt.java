package com.mediatek.settings.ext;

public interface ISimRoamingExt {

    /**
     * show Toast for succeeding to enable or disable pin lock
     * @internal
     */
    void showPinToast(boolean enable);
}
