package com.mediatek.settings.ext;

public interface IWWOPJoynSettingsExt {
    /**
     * If true, Add rcs setting preference in wireless settings.
     * @internal
     */
    boolean isJoynSettingsEnabled();
}
